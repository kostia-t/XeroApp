﻿namespace Xero.Api.Core.Model.Types
{
    public enum BudgetSummaryTimeframeType
    {
        None = 0,
        Month = 1,
        Quarter = 3,
        Year = 12
    }
}