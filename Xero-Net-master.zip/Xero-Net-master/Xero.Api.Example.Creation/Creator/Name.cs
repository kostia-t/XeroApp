﻿namespace Xero.Api.Example.Creation.Creator
{
    public class Name
    {
        public string Given { get; set; }
        public string Family { get; set; }
    }
}
